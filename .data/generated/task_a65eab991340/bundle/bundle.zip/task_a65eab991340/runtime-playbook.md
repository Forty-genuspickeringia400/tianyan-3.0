# Runtime Playbook

- **goal**: Produce a runtime operations playbook for: Build a seven-layer runtime with docs, tests, api, implementation and installable skill pack
## operators
- planner
- executor
- verifier
- bundle exporter

## controls
- approval
- retry
- run-subtasks
- background consolidation

- **runtime_mode**: skill-pack