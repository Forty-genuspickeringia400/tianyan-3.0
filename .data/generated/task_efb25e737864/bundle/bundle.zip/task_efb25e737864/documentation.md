# Documentation Outline

## sections
- overview
- architecture
- api
- verification
- operations
- skill-packaging

## references
- skill-blueprint
- runtime-playbook
- implementation-plan
- api-contract
- test-strategy
- documentation

- **note**: Generated for: Build a seven-layer runtime with docs, tests, api, implementation and installable skill pack