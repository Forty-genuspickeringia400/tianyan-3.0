# Skill Blueprint

- **sku**: agentx-skill-pack
## trigger_examples
- 需要把能力封装成 OpenClaw skill
- 需要可售卖的任务交付包

## input_schema
- goal:string
- context?:object
- constraints?:string[]

## output_schema
- task_id
- status
- artifacts
- bundle
- skill_pack

## packaging_outputs
- skill-pack/README.md
- skill-pack/index.json
- skill-pack/manifest.json
- skill-pack/<generated>/SKILL.md
- skill-pack/<generated>/skill.json
- skill-pack/<generated>-<version>.skill

## deliverables
- skill-blueprint
- runtime-playbook
- implementation-plan
- api-contract
- test-strategy
- documentation

- **track**: skill-pack